import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, LayoutDashboard, Wallet, History, UserCircle2, LogOut, CheckSquare, AlertOctagon, ScrollText, Menu, X } from "lucide-react";

type NavLink = { to: string; label: string; icon: typeof Wallet; exact?: boolean };
const links: NavLink[] = [
  { to: "/finance", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/finance/pending", label: "Maker Queue", icon: Wallet },
  { to: "/finance/checker", label: "Checker Queue", icon: CheckSquare },
  { to: "/finance/failed", label: "Failed", icon: AlertOctagon },
  { to: "/finance/history", label: "History", icon: History },
  { to: "/finance/audit", label: "Audit", icon: ScrollText },
  { to: "/finance/profile", label: "Profile", icon: UserCircle2 },
];

export function TopNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-navy-100 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link to="/finance" className="flex min-w-0 items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-navy-900 text-white shadow-sm">
            <ShieldCheck size={22} />
          </div>
          <div className="min-w-0 leading-tight">
            <div className="truncate font-display text-lg font-bold text-navy-900">TalentBridge</div>
            <div className="truncate text-[11px] font-semibold uppercase tracking-widest text-navy-500">
              Finance &amp; Accounts
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map(({ to, label, icon: Icon, exact }) => (
            <Link
              key={to}
              to={to as "/finance"}
              activeOptions={{ exact: !!exact }}
              activeProps={{ className: "bg-navy-900 text-white" }}
              inactiveProps={{ className: "text-navy-700 hover:bg-navy-50" }}
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition"
            >
              <Icon size={16} />
              {label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden text-right sm:block">
            <div className="text-sm font-semibold text-navy-900">Meera Iyer · Checker</div>
            <div className="text-[11px] font-medium uppercase tracking-wider text-success-700">
              ● Secure Session
            </div>
          </div>
          <button
            type="button"
            className="rounded-lg border border-navy-100 p-2 text-navy-700 transition hover:bg-navy-50"
            aria-label="Sign out"
          >
            <LogOut size={16} />
          </button>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="rounded-lg border border-navy-100 p-2 text-navy-700 transition hover:bg-navy-50 lg:hidden"
            aria-label="Toggle menu"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-navy-100 bg-white px-4 py-3 lg:hidden">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {links.map(({ to, label, icon: Icon, exact }) => (
              <Link
                key={to}
                to={to as "/finance"}
                activeOptions={{ exact: !!exact }}
                onClick={() => setOpen(false)}
                activeProps={{ className: "bg-navy-900 text-white" }}
                inactiveProps={{ className: "text-navy-700 bg-navy-50/60 hover:bg-navy-50" }}
                className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition"
              >
                <Icon size={16} /> {label}
              </Link>
            ))}
          </div>
        </nav>
      ) : null}
    </header>
  );
}