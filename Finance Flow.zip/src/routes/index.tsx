import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-navy-50/40 px-6 font-sans">
      <div className="max-w-xl rounded-3xl border border-navy-100 bg-white p-10 text-center shadow-xl">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-navy-900 text-white">
          <ShieldCheck size={26} />
        </div>
        <h1 className="mt-5 font-display text-3xl font-bold text-navy-900">TalentBridge</h1>
        <p className="mt-1 text-sm font-semibold uppercase tracking-widest text-navy-500">
          CSR Scholarship Management
        </p>
        <p className="mt-4 text-sm text-navy-700">
          Enter the secure Finance &amp; Accounts portal to verify beneficiary bank details and disburse approved scholarships.
        </p>
        <Link
          to="/finance"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-navy-900 px-6 py-3 font-semibold text-white transition hover:bg-navy-700"
        >
          Enter Finance Portal <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
