import { createFileRoute } from "@tanstack/react-router";
import MetricsRow from "@/components/admin/MetricsRow";
import FunnelChart from "@/components/admin/FunnelChart";
import WorkloadChart from "@/components/admin/WorkloadChart";
import ZoneDistribution from "@/components/admin/ZoneDistribution";
import CriticalAlerts from "@/components/admin/CriticalAlerts";

export const Route = createFileRoute("/admin/")({
  component: OverviewPage,
});

function OverviewPage() {
  return (
    <div className="space-y-5">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight text-slate-900">Overview</h1>
          <p className="text-sm text-slate-500 mt-0.5">A snapshot of applications, funds, and bottlenecks.</p>
        </div>
      </header>

      <MetricsRow />

      <div className="grid grid-cols-12 gap-5">
        <div className="col-span-12 md:col-span-5">
          <FunnelChart />
        </div>
        <div className="col-span-12 md:col-span-7">
          <WorkloadChart />
        </div>
        <div className="col-span-12 md:col-span-5">
          <CriticalAlerts />
        </div>
        <div className="col-span-12 md:col-span-7">
          <ZoneDistribution />
        </div>
      </div>
    </div>
  );
}
