import { createFileRoute, Outlet } from "@tanstack/react-router";
import Sidebar from "@/components/admin/Sidebar";
import Topbar from "@/components/admin/Topbar";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Scholarship Management" },
      { name: "description", content: "Overview of scholarship applications, pipeline, and disbursement." },
    ],
  }),
  component: AdminLayout,
});

function AdminLayout() {
  return (
    <div className="h-screen overflow-hidden bg-slate-50 text-slate-900 font-sans antialiased">
      <div className="flex h-full">
        <Sidebar />
        <main className="flex-1 min-w-0 flex flex-col h-full">
          <Topbar />
          <div className="flex-1 overflow-y-auto px-6 py-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
