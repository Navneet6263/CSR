import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/admin/$")({
  component: Placeholder,
});

function Placeholder() {
  return (
    <div className="rounded-xl border border-slate-200/80 bg-white p-10 text-center">
      <h2 className="text-lg font-semibold text-slate-900">Coming soon</h2>
      <p className="mt-1 text-sm text-slate-500">This section hasn't been built yet.</p>
    </div>
  );
}
