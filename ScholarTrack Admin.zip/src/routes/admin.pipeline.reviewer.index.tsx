import { createFileRoute, Link } from "@tanstack/react-router";
import {
  FileCheck2,
  Clock,
  XCircle,
  Users,
  ArrowUpRight,
  CircleDot,
} from "lucide-react";
import AgentPerformance, { type AgentPerf } from "@/components/admin/AgentPerformance";
import SLAPill from "@/components/admin/SLAPill";
import { getSLALevel, SLA_STYLES } from "@/lib/sla";

export const Route = createFileRoute("/admin/pipeline/reviewer/")({
  component: ReviewerDashboard,
});

const KPIS = [
  { label: "In Queue", value: "248", delta: "+12 today", icon: Clock },
  { label: "Verified Today", value: "186", delta: "+8.4%", icon: FileCheck2 },
  { label: "Rejected Today", value: "23", delta: "−2.1%", icon: XCircle },
  { label: "Active Checkers", value: "14", delta: "of 18", icon: Users },
];

const CHECKERS: AgentPerf[] = [
  { name: "Rohan Mehta", pending: 6, done: 42, accuracy: 98, avgTime: "12m", status: "online" },
  { name: "Priya Iyer", pending: 4, done: 38, accuracy: 96, avgTime: "14m", status: "online" },
  { name: "Arjun Kapoor", pending: 9, done: 31, accuracy: 92, avgTime: "21m", status: "online" },
  { name: "Sneha Rao", pending: 3, done: 27, accuracy: 99, avgTime: "11m", status: "idle" },
  { name: "Vikram Singh", pending: 11, done: 24, accuracy: 89, avgTime: "28m", status: "offline" },
];

const QUEUE = [
  { id: "APP-1042", name: "Ananya Sharma", college: "Fergusson College", assigned: "Rohan", waiting: "12m" },
  { id: "APP-1041", name: "Karthik Nair", college: "IIT Madras", assigned: "Priya", waiting: "28m" },
  { id: "APP-1040", name: "Meera Joshi", college: "St. Xavier's", assigned: "Arjun", waiting: "1h 04m" },
  { id: "APP-1039", name: "Rahul Verma", college: "DU North Campus", assigned: "Unassigned", waiting: "5h 12m" },
  { id: "APP-1038", name: "Divya Patel", college: "VJTI Mumbai", assigned: "Sneha", waiting: "1d 4h" },
  { id: "APP-1037", name: "Aman Gupta", college: "BITS Pilani", assigned: "Rohan", waiting: "2d 6h" },
];

function ReviewerDashboard() {
  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-slate-400">Role Dashboard</div>
          <h1 className="mt-1 text-xl font-semibold text-slate-900">Document Checkers</h1>
          <p className="mt-0.5 text-sm text-slate-500">
            Live overview of document verification team and queue.
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1 text-xs text-slate-600">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
          Live · syncing
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {KPIS.map((k) => (
          <div key={k.label} className="rounded-xl border border-slate-200/80 bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="text-[10px] uppercase tracking-widest text-slate-400">{k.label}</div>
              <k.icon className="h-3.5 w-3.5 text-slate-400" strokeWidth={1.75} />
            </div>
            <div className="mt-2 text-2xl font-semibold text-slate-900">{k.value}</div>
            <div className="mt-0.5 text-xs text-slate-500">{k.delta}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <AgentPerformance agents={CHECKERS} />
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white shadow-sm lg:col-span-7">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
            <div className="text-[10px] uppercase tracking-widest text-slate-400">Live Queue · SLA</div>
            <div className="flex items-center gap-3 text-[10px] text-slate-400">
              <span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />On track</span>
              <span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-amber-500" />At risk</span>
              <span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-rose-500" />Breached</span>
            </div>
          </div>
          <div className="divide-y divide-slate-100">
            {QUEUE.map((q) => {
              const lvl = getSLALevel(q.waiting);
              const rowCls = SLA_STYLES[lvl].row;
              return (
                <Link
                  key={q.id}
                  to="/admin/pipeline/reviewer/$id"
                  params={{ id: q.id }}
                  className={`group flex items-center gap-3 px-5 py-3 transition hover:bg-slate-50 ${rowCls}`}
                >
                  <CircleDot className="h-3.5 w-3.5 text-slate-300 group-hover:text-slate-500" strokeWidth={1.75} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-900">{q.name}</span>
                      <span className="text-xs text-slate-400">{q.id}</span>
                    </div>
                    <div className="truncate text-xs text-slate-500">{q.college} · {q.assigned}</div>
                  </div>
                  <SLAPill waiting={q.waiting} />
                  <ArrowUpRight className="h-3.5 w-3.5 text-slate-300 transition group-hover:text-slate-900" strokeWidth={1.75} />
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
