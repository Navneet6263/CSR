import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Scholarship Management" },
      { name: "description", content: "Admin console for scholarship operations." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen grid place-items-center bg-slate-50">
      <div className="text-center">
        <h1 className="text-2xl font-semibold text-slate-900">Scholarship Management</h1>
        <p className="mt-2 text-sm text-slate-500">Open the admin console to get started.</p>
        <Link
          to="/admin"
          className="mt-5 inline-flex rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          Go to Admin
        </Link>
      </div>
    </div>
  );
}
